<?php
/**
 * Classe Funcionario
 * Propósito: representa quem trabalha no banco.
 * Relacionamentos:
 *   - É PARTE de Banco (agregação). Pode trabalhar em outro banco.
 *   - ASSOCIAÇÃO BIDIRECIONAL com Cliente (carteira de clientes)
 *   - DEPENDÊNCIA de Conta (usa a conta só no método depositar)
 */
class Funcionario {
    private $nome;
    private $cargo;
    private $clientes = []; // carteira de clientes (bidirecional)

    public function __construct($nome, $cargo) {
        $this->nome = $nome;
        $this->cargo = $cargo;
    }

    // Estabelece a associação nos DOIS lados (sincronização)
    public function adicionarClienteCarteira(Cliente $cliente) {
        $this->clientes[] = $cliente;
        $cliente->setGerente($this);
    }

    // DEPENDÊNCIA: a Conta chega por parâmetro e não é guardada
    public function depositar(Conta $conta, $valor) {
        $conta->depositar($valor);
        echo "{$this->nome} depositou R$ " . number_format($valor, 2, ',', '.')
            . " na conta {$conta->getNumero()}\n";
    }

    public function getQuantidadeClientes() {
        return count($this->clientes);
    }

    public function getNome() {
        return $this->nome;
    }

    public function getCargo() {
        return $this->cargo;
    }
}
