<?php
/**
 * Classe Banco (o "todo")
 * Propósito: organiza e gerencia clientes e funcionários.
 * Relacionamentos:
 *   - AGREGA Clientes     (Banco <>---- Cliente)
 *   - AGREGA Funcionarios (Banco <>---- Funcionario)
 */
class Banco {
    private $nome;
    private $clientes = [];     // coleção de objetos Cliente
    private $funcionarios = []; // coleção de objetos Funcionario

    public function __construct($nome) {
        $this->nome = $nome;
    }

    public function adicionarCliente(Cliente $cliente) {
        $this->clientes[] = $cliente;
    }

    public function adicionarFuncionario(Funcionario $funcionario) {
        $this->funcionarios[] = $funcionario;
    }

    public function listarClientes() {
        echo "Clientes do {$this->nome}:\n";
        foreach ($this->clientes as $cliente) {
            $gerente = $cliente->getGerente();
            $nomeGerente = $gerente ? $gerente->getNome() : "sem gerente";
            echo "- {$cliente->getNome()} | Saldo total: R$ "
                . number_format($cliente->getSaldoTotal(), 2, ',', '.')
                . " | Gerente: {$nomeGerente}\n";
        }
    }

    public function listarFuncionarios() {
        echo "Funcionários do {$this->nome}:\n";
        foreach ($this->funcionarios as $f) {
            echo "- {$f->getNome()} ({$f->getCargo()}) | Clientes na carteira: "
                . "{$f->getQuantidadeClientes()}\n";
        }
    }
}
