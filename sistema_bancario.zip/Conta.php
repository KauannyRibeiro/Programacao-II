<?php
/**
 * Classe Conta
 * Propósito: representa uma conta bancária com saldo.
 * Relacionamentos:
 *   - É PARTE de Cliente (agregação). Existe sozinha.
 *   - ASSOCIAÇÃO UNIDIRECIONAL com Agencia: guarda a referência $agencia.
 */
class Conta {
    private $numero;
    private $saldo;
    private $agencia; // referência unidirecional (Agencia não conhece Conta)

    public function __construct($numero, Agencia $agencia, $saldo = 0) {
        $this->numero = $numero;
        $this->agencia = $agencia;
        $this->saldo = $saldo;
    }

    // Adiciona dinheiro à conta
    public function depositar($valor) {
        $this->saldo += $valor;
    }

    // Retira dinheiro da conta, se houver saldo suficiente
    public function sacar($valor) {
        if ($valor <= $this->saldo) {
            $this->saldo -= $valor;
            return true;
        }
        return false;
    }

    public function getNumero() {
        return $this->numero;
    }

    public function getSaldo() {
        return $this->saldo;
    }

    public function getAgencia() {
        return $this->agencia;
    }
}
