<?php
/**
 * Classe Agencia
 * Propósito: representa uma agência do banco.
 * Relacionamento: é conhecida por Conta (unidirecional). Não conhece as contas.
 */
class Agencia {
    private $numero;
    private $cidade;

    public function __construct($numero, $cidade) {
        $this->numero = $numero;
        $this->cidade = $cidade;
    }

    public function getNumero() {
        return $this->numero;
    }

    public function getCidade() {
        return $this->cidade;
    }
}
