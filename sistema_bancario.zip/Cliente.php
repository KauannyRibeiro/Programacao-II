<?php
/**
 * Classe Cliente
 * Propósito: representa uma pessoa que usa o banco.
 * Relacionamentos:
 *   - AGREGA várias Contas (Cliente <>---- Conta)
 *   - É PARTE de Banco (Banco <>---- Cliente)
 *   - ASSOCIAÇÃO BIDIRECIONAL com Funcionario (gerente)
 */
class Cliente {
    private $nome;
    private $cpf;
    private $contas = []; // coleção de objetos Conta
    private $gerente;     // referência ao Funcionario (bidirecional)

    public function __construct($nome, $cpf) {
        $this->nome = $nome;
        $this->cpf = $cpf;
    }

    // Recebe uma Conta já criada (não cria dentro da classe = agregação)
    public function adicionarConta(Conta $conta) {
        $this->contas[] = $conta;
    }

    // Soma o saldo de todas as contas do cliente
    public function getSaldoTotal() {
        $total = 0;
        foreach ($this->contas as $conta) {
            $total += $conta->getSaldo();
        }
        return $total;
    }

    public function setGerente(Funcionario $gerente) {
        $this->gerente = $gerente;
    }

    public function getGerente() {
        return $this->gerente;
    }

    public function getNome() {
        return $this->nome;
    }

    public function getCpf() {
        return $this->cpf;
    }
}
