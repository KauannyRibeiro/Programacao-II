<?php
/*
 * SISTEMA BANCÁRIO - Atividades de Associação e Agregação
 * Programação II - Ciência da Computação - UNOESC
 *
 * AGREGAÇÃO (losango branco no UML):
 *   Banco   <>---- Cliente      (banco "tem" clientes)
 *   Banco   <>---- Funcionario  (banco "tem" funcionários)
 *   Cliente <>---- Conta        (cliente "tem" contas)
 *
 * ASSOCIAÇÕES:
 *   Conta   ----> Agencia       (UNIDIRECIONAL: a conta conhece a agência)
 *   Cliente <---> Funcionario   (BIDIRECIONAL: cliente conhece seu gerente
 *                                e o gerente conhece seus clientes)
 *   Funcionario - - -> Conta    (DEPENDÊNCIA: o funcionário usa a conta
 *                                só durante o método depositar())
 */

// Carrega uma classe por arquivo
require_once __DIR__ . '/Agencia.php';
require_once __DIR__ . '/Conta.php';
require_once __DIR__ . '/Cliente.php';
require_once __DIR__ . '/Funcionario.php';
require_once __DIR__ . '/Banco.php';

/* ============================================================
 * EXEMPLO DE USO
 * ============================================================ */

// 1) Criação dos objetos (cada um existe de forma independente)
$agencia = new Agencia("0123", "Joaçaba");
$conta1  = new Conta("0001-5", $agencia, 1000); // associação unidirecional
$conta2  = new Conta("0002-7", $agencia, 500);
$maria   = new Cliente("Maria Silva", "111.111.111-11");
$joao    = new Cliente("João Souza", "222.222.222-22");
$carlos  = new Funcionario("Carlos Lima", "Gerente");
$ana     = new Funcionario("Ana Rocha", "Caixa");

// 2) Estabelecimento da agregação
$maria->adicionarConta($conta1);
$maria->adicionarConta($conta2);

$banco = new Banco("Banco UNOESC");
$banco->adicionarCliente($maria);
$banco->adicionarCliente($joao);
$banco->adicionarFuncionario($carlos);
$banco->adicionarFuncionario($ana);

// 3) Estabelecimento da associação bidirecional (gerente <-> cliente)
$carlos->adicionarClienteCarteira($maria);

// 4) Uso dos métodos
$conta2->sacar(100);
$ana->depositar($conta1, 250); // dependência: Funcionario usa Conta

$banco->listarClientes();
echo "\n";
$banco->listarFuncionarios();

// 5) Navegação nas associações
echo "\nA conta {$conta1->getNumero()} pertence à agência "
    . "{$conta1->getAgencia()->getNumero()} ({$conta1->getAgencia()->getCidade()})\n";
echo "O gerente de {$maria->getNome()} é {$maria->getGerente()->getNome()}\n";

// 6) Prova da independência: a conta existe fora do Cliente e do Banco
echo "Conta {$conta1->getNumero()} (acessada direto): R$ "
    . number_format($conta1->getSaldo(), 2, ',', '.') . "\n";
