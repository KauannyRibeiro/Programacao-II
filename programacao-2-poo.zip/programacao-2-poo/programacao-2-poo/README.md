# Programação II – POO em PHP

**Aluna:** Kauanny Ribeiro da Silva (448187)
**Professor:** Leandro Otavio Cordova Vieira

## A1/1 – Visibilidade (Unidade I)

Os 10 exercícios estão em `a1-1-visibilidade/`, um arquivo por exercício.
Obs; Necessário o PHP instalado para executar os codigos