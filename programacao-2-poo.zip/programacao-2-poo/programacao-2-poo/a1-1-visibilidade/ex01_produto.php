<?php
class Produto {
    // Atributos
    public $nome;
    public $preco;
}

// Testando
$produto = new Produto();
$produto->nome = "Caneta da Kau";
$produto->preco = 3.5;

echo "Nome: $produto->nome\n";
echo "Preço: R$ $produto->preco\n";
