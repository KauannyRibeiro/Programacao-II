<?php
class ConexaoBD {
    private $conexao = null;

    // Método privado: só a própria classe pode conectar
    private function conectar() {
        try {
            // SQLite em memória, para rodar sem configurar servidor
            $this->conexao = new PDO("sqlite::memory:");
            $this->conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Erro na conexão: " . $e->getMessage());
        }
    }

    // Único método público
    public function getConexao() {
        if ($this->conexao === null) {
            $this->conectar();
        }
        return $this->conexao;
    }
}

// Testando
$bd = new ConexaoBD();
$pdo = $bd->getConexao();
echo "Conexão criada por Kauanny: " . get_class($pdo) . "\n";
// $bd->conectar(); // ERRO: método privado
