<?php
class Cliente {
    public $nome;
    protected $cpf;
    private $telefone;

    public function __construct($nome, $cpf, $telefone) {
        $this->nome = $nome;
        $this->cpf = $cpf;
        $this->telefone = $telefone;
    }

    // Dentro da classe: acessa os três atributos
    public function exibirDados() {
        echo "Nome: $this->nome | CPF: $this->cpf | Telefone: $this->telefone\n";
    }
}

class ClienteVip extends Cliente {
    // Subclasse: acessa o protected, mas não o private
    public function mostrarCpf() {
        return $this->cpf;
    }
}

// Testando
$cliente = new ClienteVip("Kauanny", "000.000.000-00", "49 99999-0000");

echo "Dentro da classe:\n";
$cliente->exibirDados();

echo "Na subclasse (CPF): " . $cliente->mostrarCpf() . "\n";

echo "Fora da classe:\n";
echo "Nome: $cliente->nome\n"; // funciona (public)

try {
    echo $cliente->cpf;
} catch (Error $e) {
    echo "Erro ao acessar cpf: " . $e->getMessage() . "\n";
}

try {
    echo $cliente->telefone;
} catch (Error $e) {
    echo "Erro ao acessar telefone: " . $e->getMessage() . "\n";
}
