<?php
class ContaBancaria {
    // Atributos
    public $titular;
    private $saldo = 0;

    // Método para depositar
    public function depositar($valor) {
        if ($valor > 0) {
            $this->saldo = $this->saldo + $valor;
            return true;
        }
        echo "Valor de depósito inválido!\n";
        return false;
    }

    // Método para sacar (somente se o saldo for suficiente)
    public function sacar($valor) {
        if ($valor <= 0) {
            echo "Valor de saque inválido!\n";
            return false;
        }
        if ($valor > $this->saldo) {
            echo "Saldo insuficiente!\n";
            return false;
        }
        $this->saldo = $this->saldo - $valor;
        return true;
    }

    public function getSaldo() {
        return $this->saldo;
    }
}

// Testando
$conta = new ContaBancaria();
$conta->titular = "Kauanny";
$conta->depositar(100);
$conta->sacar(30);  // permitido
$conta->sacar(500); // Saldo insuficiente!
echo "Titular: $conta->titular\n";
echo "Saldo final: R$ " . $conta->getSaldo() . "\n";
