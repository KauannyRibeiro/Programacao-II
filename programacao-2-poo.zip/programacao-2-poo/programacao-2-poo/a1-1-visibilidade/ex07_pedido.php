<?php
class Pedido {
    private $itens = [];

    // Insere um item no pedido
    public function inserirItem($item) {
        $this->itens[] = $item;
    }

    // Lista os itens do pedido
    public function listarItens() {
        if (count($this->itens) == 0) {
            echo "Pedido vazio.\n";
            return;
        }
        foreach ($this->itens as $indice => $item) {
            echo ($indice + 1) . " - $item\n";
        }
    }
}

// Testando
$pedido = new Pedido();
$pedido->inserirItem("Caneta");
$pedido->inserirItem("Caderno da Kau");
$pedido->inserirItem("Mochila");
echo "Itens do pedido de Kauanny:\n";
$pedido->listarItens();
