<?php
class ContaBancaria {
    // Atributos
    public $titular;
    private $saldo = 0;

    // Método para depositar
    public function depositar($valor) {
        if ($valor > 0) {
            $this->saldo = $this->saldo + $valor;
        } else {
            echo "Valor de depósito inválido!\n";
        }
    }

    // Método para sacar
    public function sacar($valor) {
        if ($valor > 0) {
            $this->saldo = $this->saldo - $valor;
        } else {
            echo "Valor de saque inválido!\n";
        }
    }

    // Getter para consultar o saldo
    public function getSaldo() {
        return $this->saldo;
    }
}

// Testando
$conta = new ContaBancaria();
$conta->titular = "Kauanny";
$conta->depositar(150);
$conta->sacar(30);
echo "Titular: $conta->titular\n";
echo "Saldo final: R$ " . $conta->getSaldo() . "\n";
