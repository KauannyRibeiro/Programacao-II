<?php
class Produto {
    // Atributos
    public $nome;
    private $preco;

    // Getter
    public function getPreco() {
        return $this->preco;
    }

    // Setter com validação
    public function setPreco($preco) {
        if ($preco > 0) {
            $this->preco = $preco;
        } else {
            echo "Preço inválido!\n";
        }
    }
}

// Testando
$produto = new Produto();
$produto->nome = "Caneta da Kau";
$produto->setPreco(3.5);
echo "Nome: $produto->nome\n";
echo "Preço: R$ " . $produto->getPreco() . "\n";

$produto->setPreco(-10); // Preço inválido!
// echo $produto->preco; // ERRO: atributo privado
