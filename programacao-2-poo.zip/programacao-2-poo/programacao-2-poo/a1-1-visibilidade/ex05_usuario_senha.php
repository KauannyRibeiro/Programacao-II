<?php
class Usuario {
    // Atributos
    public $email;
    private $senha;

    public function __construct($email, $senha) {
        $this->email = $email;
        $this->senha = password_hash($senha, PASSWORD_DEFAULT);
    }

    // Retorna true ou false
    public function verificarSenha($senhaDigitada) {
        return password_verify($senhaDigitada, $this->senha);
    }
}

// Testando
$usuario = new Usuario("kau@email.com", "kau1234");
echo "Senha correta: " . ($usuario->verificarSenha("kau1234") ? "true" : "false") . "\n";
echo "Senha errada: " . ($usuario->verificarSenha("outra") ? "true" : "false") . "\n";
