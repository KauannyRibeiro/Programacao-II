<?php
class Funcionario {
    // Atributos
    public $nome;
    protected $salario;

    public function __construct($nome, $salario) {
        $this->nome = $nome;
        $this->salario = $salario;
    }
}

class Gerente extends Funcionario {
    // Acessa o atributo protegido da classe pai
    public function getSalario() {
        return $this->salario;
    }

    // Modifica o atributo protegido da classe pai
    public function setSalario($novoSalario) {
        if ($novoSalario > 0) {
            $this->salario = $novoSalario;
        }
    }
}

// Testando
$gerente = new Gerente("Kauanny", 5000);
echo "Salário atual: R$ " . $gerente->getSalario() . "\n";
$gerente->setSalario(6500);
echo "Novo salário: R$ " . $gerente->getSalario() . "\n";
// echo $gerente->salario; // ERRO: protegido, inacessível fora da hierarquia
