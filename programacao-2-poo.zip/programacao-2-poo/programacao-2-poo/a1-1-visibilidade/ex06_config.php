<?php
class Config {
    protected $parametros = [];

    public function __construct($parametros) {
        $this->parametros = $parametros;
    }
}

// Subclasse que lê os parâmetros
class LeitorConfig extends Config {
    public function ler($chave) {
        return $this->parametros[$chave] ?? "Parâmetro não encontrado";
    }
}

// Subclasse que modifica os parâmetros
class EditorConfig extends Config {
    public function alterar($chave, $valor) {
        $this->parametros[$chave] = $valor;
    }

    public function listar() {
        foreach ($this->parametros as $chave => $valor) {
            echo "$chave = $valor\n";
        }
    }
}

// Testando
$dados = ["idioma" => "pt-BR", "autor" => "Kauanny"];

$leitor = new LeitorConfig($dados);
echo "Idioma: " . $leitor->ler("idioma") . "\n";

$editor = new EditorConfig($dados);
$editor->alterar("idioma", "en-US");
$editor->listar();
